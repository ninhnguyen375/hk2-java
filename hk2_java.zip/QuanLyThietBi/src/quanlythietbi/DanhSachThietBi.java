/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlythietbi;

import java.awt.Color;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author ninh
 */
public class DanhSachThietBi {

    private ArrayList<LinhKien> mangThietBi = new ArrayList<LinhKien>();
    Scanner sn = new Scanner(System.in);

    public void nhap() throws ParseException {
        System.out.print("Nhap so luong can nhap:");
        int soluong = Integer.parseInt(sn.nextLine());
        for (int i = 0; i < soluong; i++) {
            System.out.println("0. Out.");
            System.out.println("1. Nhap Linh Kien.");
            System.out.println("2. Nhap Dien Thoai.");
            String choose = sn.nextLine();
            switch (choose) {
                case "1": {
                    LinhKien thietbi = new LinhKien();
                    thietbi.nhap();
                    mangThietBi.add(thietbi);
                    break;
                }
                case "2": {
                    LinhKien thietbi = new DienThoai();
                    thietbi.nhap();
                    mangThietBi.add(thietbi);
                    break;
                }
                default:
                    break;
            }
        }
    }

    public void tongGiaTienCuaTatCaLinhKien() {
        double tong = 0;
        for (int i = 0; i < mangThietBi.size(); i++) {
            tong += mangThietBi.get(i).getGia();
        }
        System.out.println("Tong Gia Tien Cua Tat Ca Linh Kien La: " + tong);
    }
    
    public DienThoai dienThoaiCoGiaLonNhat(){
        double max = 0;
        DienThoai dt = null;
        for (int i = 0; i < mangThietBi.size(); i++) {
            double gia = mangThietBi.get(i).getGia();
            if(gia > max) {
              max = gia;
              dt = (DienThoai) mangThietBi.get(i);
            }
        }
        return dt;
    }

    public ArrayList<LinhKien> getMangThietBi() {
        return mangThietBi;
    }
    
    public void xoaThietBi() throws ParseException {
        Date d = new SimpleDateFormat("dd/mm/yyyy").parse("31/01/1990");
        for (int i = 0; i < mangThietBi.size(); i++) {
            if(mangThietBi.get(i).getNgayNhap().before(d)){
                mangThietBi.remove(i);
            }
        }
    }
    
    public void sapXep() {
        for (int i = 0; i < mangThietBi.size() - 1; i++) {
            for (int j = i + 1; j < mangThietBi.size(); j++) {
                Date datei = mangThietBi.get(i).getNgayNhap();
                Date datej = mangThietBi.get(j).getNgayNhap();
                if(datei.after(datej)){
                    Collections.swap(mangThietBi, i, j);
                }
            }
        }
    }
    
    public void xuat() {
        System.out.println(">============< Danh Sach Thiet Bi >============<");
        for (int i = 0; i < mangThietBi.size(); i++) {
            mangThietBi.get(i).xuat();
        }
        System.out.println(">==============================================<");
    }

    public void setMangThietBi(ArrayList<LinhKien> mangThietBi) {
        this.mangThietBi = mangThietBi;
    }

    public DanhSachThietBi() {
    }
}
