package quanlythietbi;

import java.text.ParseException;

/**
 *
 * @author ninh
 */
public class Main {

    public static void main(String[] args) throws ParseException {
        DanhSachThietBi ds = new DanhSachThietBi();
        ds.nhap();
        ds.xuat();
        ds.sapXep();
        ds.xuat();
    }
    
}
