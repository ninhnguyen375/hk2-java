package quanlythietbi;

import java.text.ParseException;
import java.util.Date;

/**
 *
 * @author ninh
 */
public class DienThoai extends LinhKien {

    public int RAM, HDD;

    // Contructor
    public DienThoai() {
    }

    public DienThoai(int RAM, int HDD, String ma, String ten, Date ngayNhap, double gia) {
        super(ma, ten, ngayNhap, gia);
        this.RAM = RAM;
        this.HDD = HDD;
    }

    // Getter and Setter
    public int getRAM() {
        return RAM;
    }

    public void setRAM(int RAM) {
        this.RAM = RAM;
    }

    public int getHDD() {
        return HDD;
    }

    public void setHDD(int HDD) {
        this.HDD = HDD;
    }

    @Override
    public void xuat() {
        super.xuat();
        System.out.println("RAM :" + RAM);
        System.out.println("HDD :" + HDD);
    }

    @Override
    public void nhap() throws ParseException {
        super.nhap();
        System.out.println("Nhap RAM:");
        RAM = Integer.parseInt(sn.nextLine());
        System.out.println("Nhap HDD:");
        HDD = Integer.parseInt(sn.nextLine());
    }

}
