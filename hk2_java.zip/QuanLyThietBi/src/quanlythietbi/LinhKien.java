/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlythietbi;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author ninh
 */
public class LinhKien {
    public String ma, ten;
    public Date ngayNhap;
    public double gia;
    Scanner sn = new Scanner(System.in);

    public LinhKien(String ma, String ten, Date ngayNhap, double gia) {
        this.ma = ma;
        this.ten = ten;
        this.ngayNhap = ngayNhap;
        this.gia = gia;
    }

    public LinhKien() {
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public Date getNgayNhap() {
        return ngayNhap;
    }

    public void setNgayNhap(Date ngayNhap) {
        this.ngayNhap = ngayNhap;
    }

    public double getGia() {
        return gia;
    }

    public void setGia(double gia) {
        this.gia = gia;
    }
    
    
    public void nhap() throws ParseException {
        System.out.println("Nhap ma:");
        ma = sn.nextLine();
        System.out.println("ten:");
        ten = sn.nextLine();
        System.out.println("ngay nhap(dd/MM/YYYY):");
        String temp = sn.nextLine();
        System.out.println("gia tien:");
        gia = Double.parseDouble(sn.nextLine());
        ngayNhap = new SimpleDateFormat("dd/mm/yyyy").parse(temp);
    }
    public void xuat(){
        System.out.println(">=====> Thong tin thiet bi:");
        System.out.println("Ma :"+ma);
        System.out.println("Ten :"+ten);
        System.out.println("Ngay nhap :"+ngayNhap);
        System.out.println("Gia :"+gia);
    }
}
