package qlnv;
import java.sql.*;
public class Main {

    public static void getConnect() {
        
    }
    public static void main(String[] args) {
        
    }
    
}
