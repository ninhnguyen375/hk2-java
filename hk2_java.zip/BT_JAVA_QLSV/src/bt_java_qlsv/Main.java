/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bt_java_qlsv;

import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author ninh
 */
public class Main {

  static Scanner sn = new Scanner(System.in);

  public static void xuatSV(Statement stmt) throws SQLException {
    System.out.println("-----------------------------------------------------------------");
    System.out.format("%-15s%-15s%-15s%-15s%-15s%n", "MaSV", "TenSV", "Ngay Sinh", "GioiTinh", "Lop");

    ResultSet rs = stmt.executeQuery("select * from SV");
    while (rs.next()) {
      System.out.format("%-15d%-15s%-15s%-15s%-15s%n",
              rs.getInt(1),
              rs.getString(2),
              rs.getString(3),
              rs.getString(4),
              rs.getString(5));
    }

    System.out.println("-----------------------------------------------------------------");
    rs.close();
  }

  public static void xuatLop(Statement stmt) throws SQLException {
    System.out.println("-----------------------------------------------------------------");
    System.out.format("%-15s%-15s%n", "MaLop", "TenLop");

    ResultSet rs = stmt.executeQuery("select * from LOP");
    while (rs.next()) {
      System.out.format("%-15d%-15s%n", rs.getInt(1), rs.getString(2));
    }

    System.out.println("-----------------------------------------------------------------");
    rs.close();
  }

  public static void themSV(Statement stmt) {
    System.out.print("Nhap Ten SV : ");
    String tenSV = sn.nextLine();

    System.out.print("Nhap Ngay Sinh (YYYY-MM-dd) : ");
    String ngaySinh = sn.nextLine();

    System.out.print("Nhap Lop : ");
    int maLop = Integer.parseInt(sn.nextLine());

    System.out.print("Nhap Gioi Tinh (1:Nam ; 2:Nu) : ");
    int gioiTinh = Integer.parseInt(sn.nextLine());

    String query = String.format("INSERT INTO `SV`"
            + " (`MaSV`, `TenSV`, `NgaySinh`, `GioiTinh`, `MaLop`) "
            + "VALUES (null, '%s', '%s', '%d', '%d')",
            tenSV, ngaySinh, gioiTinh, maLop);
    try {
      stmt.executeUpdate(query);
    } catch (Exception e) {
      System.out.println(e);
    }
  }

  public static void themLop(Statement stmt) {
    System.out.print("Nhap Ten Lop : ");
    String tenLop = sn.nextLine();

    String query = String.format("INSERT INTO `LOP`"
            + " (`MaLop`, `TenLop`) "
            + "VALUES (null, '%s')",
            tenLop);
    try {
      stmt.executeUpdate(query);
    } catch (Exception e) {
      System.out.println(e);
    }
  }

  public static void xoaSVTheoMaSV(Statement stmt) {
    System.out.print("Nhap ma sv can xoa : ");
    int maSV = Integer.parseInt(sn.nextLine());

    String query = String.format("DELETE FROM `SV` WHERE `SV`.`MaSV` = %d;", maSV);

    try {
      stmt.executeUpdate(query);
    } catch (Exception e) {
      System.out.println(e);
    }
  }

  public static void chuyenLopCuaSV(Statement stmt) {
    System.out.print("Nhap ma SV can chuyen : ");
    int maSV = Integer.parseInt(sn.nextLine());

    System.out.print("Nhap ma lop can chuyen : ");
    int maLop = Integer.parseInt(sn.nextLine());

    String query = String.format("UPDATE `SV` SET `MaLop` = '%d' WHERE `SV`.`MaSV` = %d;", maLop, maSV);

    try {
      stmt.executeUpdate(query);
    } catch (Exception e) {
      System.out.println(e);
    }
  }

  public static void xoaSVTheoLop(Statement stmt) {
    System.out.print("Nhap ma lop can xoa : ");
    int maLop = Integer.parseInt(sn.nextLine());

    String query = String.format("DELETE FROM `SV` WHERE `SV`.`MaLop` = %d;", maLop);

    try {
      stmt.executeUpdate(query);
    } catch (Exception e) {
      System.out.println(e);
    }
  }

  public static void main(String[] args) {
    String driver_name = "com.mysql.jdbc.Driver";
    String database = "BT_JAVA_QLSV";
    String user_name = "ninh";
    String user_password = "Ninhnguyen375.";
    String mysql_uri = "jdbc:mysql://localhost:3306/" + database;
    try {
      // Config
      Class.forName(driver_name);
      Connection con = DriverManager.getConnection(mysql_uri, user_name, user_password);
      Statement stmt = con.createStatement();

      while (true) {
        System.out.println("1.Xuat DS SV");
        System.out.println("2.Xuat DS LOP");
        System.out.println("3.Them Lop");
        System.out.println("4.Them SV");
        System.out.println("5.Chuyen Lop Cua SV");
        System.out.println("6.Xoa SV Theo Lop");
        System.out.println("7.Xoa SV Theo Ma");
        System.out.println("0.Thoat");
        
        String choose = sn.nextLine();
        if(choose.equals("0")) break;
        switch (choose) {
          case "1":
            xuatSV(stmt);
            break;
          case "2":
            xuatLop(stmt);
            break;
          case "3":
            themLop(stmt);
            break;
          case "4":
            themSV(stmt);
            break;
          case "5":
            chuyenLopCuaSV(stmt);
            break;
          case "6":
            xoaSVTheoLop(stmt);
            break;
          case "7":
            xoaSVTheoMaSV(stmt);
            break;
          default: break;
        }
      }
      stmt.close();
      con.close();
    } catch (ClassNotFoundException | SQLException e) {
      System.out.println(e);
    }
  }

}
