
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Phong
 */
public class HSCap3 extends HS{
    private int dLy,dTiengAnh;
    Scanner s=new Scanner(System.in);
    public HSCap3(){}
    public HSCap3(String MaHS, String TenHS,int dToan, int dVan, int dLy,int dTiengAnh){
        super(MaHS,TenHS,dToan,dVan);
        this.dLy=dLy;
        this.dTiengAnh=dTiengAnh;
    }
    @Override
    public void nhap(){
        super.nhap();
        System.out.print("Diem Ly: ");
        dLy=s.nextInt();
        System.out.print("Diem Tieng Anh: ");
        dTiengAnh=s.nextInt();
    }
    @Override
    public void xuat(){
        super.xuat();
        System.out.println("Diem Ly: "+dLy+"\nDiem Tieng Anh: "+dTiengAnh);
    }
    @Override
    public double getDTB(){
        return (getToan()+getVan()+dLy+dTiengAnh)/4;
    }
}
