
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Phong
 */
public class HSCap2 extends HS{
    private int dLy;
    Scanner s=new Scanner(System.in);
    public HSCap2(){}
    public HSCap2(String MaHS, String TenHS,int dToan, int dVan, int dLy){
        super(MaHS,TenHS,dToan,dVan);
        this.dLy=dLy;
    }
    @Override
    public void nhap(){
        super.nhap();
        System.out.print("Diem Ly: ");
        dLy=s.nextInt();
    }
    @Override
    public void xuat(){
        super.xuat();
        System.out.println("Diem Ly: "+dLy);
    }
    @Override
    public double getDTB(){
        return (getToan()+getVan()+dLy)/3;
    }
}
