
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Phong
 */
public class HSCap1 extends HS{
    public HSCap1(){}
    public HSCap1(String MaHS, String TenHS,int dToan, int dVan){
        super(MaHS,TenHS,dToan,dVan);
    }
}
