
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Phong
 */
public class HS {
    private String MaHS,TenHS;
    private int dToan,dVan;
    Scanner s=new Scanner(System.in);
    public HS(){}
    public HS(String MaHS, String TenHS,int dToan, int dVan){
        this.MaHS=MaHS;
        this.TenHS=TenHS;
        this.dToan=dToan;
        this.dVan=dVan;
    }
    public void nhap(){
        System.out.print("Ma HS: ");
        MaHS=s.nextLine();
        System.out.print("Ten HS: ");
        TenHS=s.nextLine();
        System.out.print("Diem Toan: ");
        dToan=s.nextInt();
        System.out.print("Diem Van: ");
        dVan=s.nextInt();
    }
    public void xuat(){
        System.out.println("Ma HS: "+MaHS+"\nTen HS: "+TenHS+"\nMa HS: "+MaHS+"\nTen HS: "+TenHS+"\nDiem Toan: "+dToan+"\nDiem Van: "+dVan);
    }
    public int getToan(){
        return dToan;
    }
    public int getVan(){
        return dVan;
    }
    public double getDTB(){
        return (dToan+dVan)/2;
    }
    public String XepLoai(){
        if (getDTB()>8.0) return "GIOI";
        else if (getDTB()>6.5) return "KHA";
        else if (getDTB()>5.0) return "TRUNG BINH";
        else return "YEU";
    }
}
