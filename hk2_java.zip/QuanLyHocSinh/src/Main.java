
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Phong
 */
public class Main {
    public static void main(String args[]){
        ArrayList<HS> arr=new ArrayList();
        System.out.println("Nhap mang HS: ");
        Scanner s=new Scanner(System.in);
        while (true){
            System.out.println("1)HS CAP 1\n2)HS CAP 2\n3)HS CAP 3");
            switch(s.nextInt()){
                case 1:
                    HS a=new HSCap1();
                    a.nhap();
                    arr.add(a);
                    break;
                case 2:
                    HS b=new HSCap2();
                    b.nhap();
                    arr.add(b);
                    break;
                case 3:
                    HS c=new HSCap3();
                    c.nhap();
                    arr.add(c);
                    break;
                default: break;
            }
            System.out.println("1)Tiep tuc\t2)Thoat");
            if (s.nextInt()==2) break;
        }
        for (int i=0;i<arr.size();++i){
            arr.get(i).xuat();
            System.out.println("Xep loai: "+arr.get(i).XepLoai()+"\n");
        }
        
    }
}
