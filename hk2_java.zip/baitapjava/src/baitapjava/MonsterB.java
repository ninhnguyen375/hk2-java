
package baitapjava;
public class MonsterB extends Monster {
    @Override
    public void nhap()
    {
      super.nhap();
    }
    @Override
    public void xuat()
    {
      super.xuat();  
    }
    @Override
    public void di()
    {
      System.out.println("Monster B move to :"+x+","+(y+2));
    }
    @Override
    public int sucmanh()
    {
      return sucmanh*10;
    }
}
