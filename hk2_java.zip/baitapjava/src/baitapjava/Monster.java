
package baitapjava;
import java.util.Scanner;
public class Monster {
    public String ma;
    public int sucmanh;
    public int x,y;
    public void nhap()
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Nhap ma Monster :");
      ma=sc.nextLine();
      System.out.println("Suc manh :");
      sucmanh=sc.nextInt();
      System.out.println("Nhap toa do x cua Monster :");
      x=sc.nextInt();
      System.out.println("Nhap toa do y cua Monster :");
      y=sc.nextInt();
    }
    public void xuat()
    {
      System.out.println("Ma Monster :"+ma);
      System.out.println("Suc manh :"+sucmanh);
      System.out.println("Toa do :"+x+","+y); 
    }
    public void di(){}
    public int sucmanh()
    {
      return 0;
    }
}
