
package baitapjava;
public class MonsterC extends Monster {
    @Override
    public void nhap()
    {
      super.nhap();
    }
    @Override
    public void xuat()
    {
      super.xuat();  
    }
    @Override
    public void di()
    {
      System.out.println("Monster C move to :"+(x+y)+","+y);
    }
    @Override
    public int sucmanh()
    {
      return sucmanh*50;
    }
}
