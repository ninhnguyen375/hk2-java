package baitapjava;

import java.util.Scanner;
import java.util.ArrayList;

public class Main {

    public static ArrayList<Monster> mang() {
        ArrayList<Monster> mang = new ArrayList();
        while (true) {
            System.out.println("Nhap tuy chon\n1.MonsterA\n2.MonsterB\n3.MonsterC\n4.Ket Thuc");
            Scanner sc = new Scanner(System.in);
            int chon = sc.nextInt();
            Monster D = null;
            if (chon == 1) {
                D = new MonsterA();
            }
            if (chon == 2) {
                D = new MonsterB();
            }
            if (chon == 3) {
                D = new MonsterC();
            }
            if (chon == 4 || chon > 4) {
                break;
            }
            D.nhap();
            mang.add(D);
        }
        return mang;
    }

    public static void xuat(ArrayList<Monster> mang) {
        for (int i = 0; i < mang.size(); i++) {
            Monster D = mang.get(i);
            D.xuat();
            System.out.print("\n");
        }
    }

    public static void dichuyen(ArrayList<Monster> mang) {
        for (int i = 0; i < mang.size(); i++) {
            Monster D = mang.get(i);
            D.di();
            System.out.print("\n");
        }
    }

    public static int power(ArrayList<Monster> mang) {
        int S = 0;
        for (int i = 0; i < mang.size(); i++) {
            Monster D = mang.get(i);
            S = S + D.sucmanh();
        }
        return S;
    }

    public static int powerlonnhat(ArrayList<Monster> mang) {
        int maximum = 0;
        for (int i = 0; i < mang.size(); i++) {
            for (int j = i + 1; j < mang.size(); j++) {
                if (mang.get(i).sucmanh() < mang.get(j).sucmanh()) {
                    maximum = mang.get(j).sucmanh();
                }
            }
        }
        return maximum;
    }

    public static void main(String args[]) {
        ArrayList<Monster> mang = mang();
        xuat(mang);
        System.out.print("\n");
        dichuyen(mang);
        System.out.println("Tong suc manh tat ca Monster :" + power(mang));
        System.out.println("Monster co chi so suc manh " + powerlonnhat(mang) + " la lon nhat :");
    }
}
