
package baitapjava;
public class MonsterA extends Monster {
    @Override
    public void nhap()
    {
      super.nhap();
    }
    @Override
    public void xuat()
    {
      super.xuat();  
    }
    @Override
    public void di()
    {
      System.out.println("Monster A move to :"+(x+2)+","+y);
    }
    @Override
    public int sucmanh()
    {
      return sucmanh*20;
    }
}
