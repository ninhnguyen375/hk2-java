package bt_database;

import java.sql.*;

public class Main {

  public static void xuatBang(Statement stmt) throws SQLException {
    System.out.println("---------------------------------------");
    
    ResultSet rs = stmt.executeQuery("select * from TenNV");
    while (rs.next()) {
      System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
    }
    
    rs.close();
  }

  public static void main(String[] args) {
    String driver_name = "com.mysql.jdbc.Driver";
    String mysql_uri = "jdbc:mysql://localhost:3306/QUANLYNV";
    String user_name = "ninh";
    String user_password = "Ninhnguyen375.";
    try {
      // Config
      Class.forName(driver_name);
      Connection con = DriverManager.getConnection(mysql_uri, user_name, user_password);
      Statement stmt = con.createStatement();

      xuatBang(stmt);

      stmt.executeUpdate("insert into TenNV (TenNV, luong) values ('Ninh dep trai', 20)");

      xuatBang(stmt);

      con.close();
    } catch (ClassNotFoundException | SQLException e) {
      System.out.println(e);
    }
  }
}
